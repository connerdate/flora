@extends('layouts.default')
@section('content')
<div class="row">
    <div class="col-md-6 col-sm-12 col-xs-12" style="margin-left: 1em; margin-top: 1em; color: #000; font-weight: bold; font-size: 1.5em; padding-left: 5px;">Calculate your investment amount</div>
</div>  

<div class="row">
<div class="col-md-11 col-sm-11 col-xs-12 div-white" style="margin-bottom: 2em;">
    <!-- Example Bar Chart Card-->
    <div class="col-md-12" style="margin-top: 1em; margin-bottom: 1em; color: #000;">
    <table id="example" class="table table-striped table-bordered table-responsive" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th scope="col">No.</th>
                <th scope="col">Date</th>
                <th scope="col">Wallet Addess</th>
                <th scope="col">Type</th>
                <th scope="col">Send</th>
                <th scope="col">FIC Recive</th>
                <th scope="col">FIC Bonus</th>
                <th scope="col">Status</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th scope="col">No.</th>
                <th scope="col">Date</th>
                <th scope="col">Wallet Addess</th>
                <th scope="col">Type</th>
                <th scope="col">Send</th>
                <th scope="col">FIC Recive</th>
                <th scope="col">FIC Bonus</th>
                <th scope="col">Status</th>
                <th scope="col"></th>
            </tr>
        </tfoot>
        <tbody>
            @php($i = 1)
            @foreach($datas as $key => $data)
                @include('backend.partials._transaction_list', ['data'=>$data,'order'=>$i])
                @php($i++)
            @endforeach
        </tbody>
    </table>
    </div>
</div>        
</div>
@endsection
@section('style')
<link href="{{asset('css/index-custom.css')}}" rel="stylesheet" type="text/css">
@endsection
@section('script')
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>
@endsection