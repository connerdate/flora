<tr>
    <th scope="row">{{$order}}</th>
    <td>{{$data->created_at->format('d-m-Y H:i:s')}}</td>
    <td>{{$data->to_wallet}}</td>
    <td>{{$data->wallet->code}}</td>
    <td>{{$data->send_value}}</td>
    <td>{{$data->fic_receive}}</td>
    <td>{{$data->fic_bonus}}</td>
    <td>{{$data->getTransactionStatusView()}}</td>
    <td>
        <a href="{{URL::to('cmscontrol/transactionData/'.$data->id)}}"><button>{{($data->status == 0)?'Edit':'View'}}</button></a>
    </td>
</tr>