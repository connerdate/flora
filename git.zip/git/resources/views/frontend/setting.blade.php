@extends('layouts.default')
@section('content')
<div class="row">

    <div class="col-md-6 col-sm-12 col-xs-12" style="margin-top: 1em; color: #000; font-weight: bold; font-size: 1.5em;">Your Setting here</div>
    </div>  

    <div class="row">
    <div class="col-md-9 col-sm-12 col-12 div-white" style="margin-bottom: 2em;">
      <br>
      <h6>Two-Factor Authentication :</h6>
      <button type="button" 
              class="btn btn-dark" 
              data-target="#show-2fa"
              data-toggle="collapse" 
              role="button" 
              aria-expanded="false" 
              aria-controls="collapseExample">Enable Two-Factor Authentication
      </button>
      <div class="collapse" id="show-2fa">
        <div class="row">
          <p class="mt-2 ml-3">Two-Factor Authentication :</p>
          <div class="w-100"></div>
          <div class="col-md-6 col-sm-6 col-xs-12"></div>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <h6>Please write down your authentication key :</h6>  
            <p><b>L6COSG6C5MMA6QZS</b></p>
            <p>Do not save the QR code in any digital form. The QR code must be printed on paper and saved in a secure place, where only you can access it.</p>
          </div>
        </div>
        <form>
          <div class="row">
            <div class="col-md-6 col-sm-6 col-12"> 
              <div class="form-group">
                <label for=""><b>Your Authentication Key :</b></label>
                <input type="text" class="form-control" id="" placeholder="L6COSG6C5MMA6QZS">
              </div>
            </div>
            <div class="col-md-6 col-sm-6 col-12"> 
              <div class="form-group">
                <label for=""><b>Enter Your 6-Digit Authentication Code :</b></label>
                <input type="text" class="form-control" id="" placeholder="">
              </div>
            </div>
          </div>
        </form>
        <div class="row" style="margin-bottom: 2em;">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <h6>IMPORTANT NOTICE</h6>
            <p>Always write down your authentication key! You will not be able to log in to your account in case you lose your mobile device. If you are having problems with our system rejecting your authentication code, check your mobile device's clock. It must be synchronized perfectly. Your device will generate a new code every 30 seconds.</p>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-12 col-sm-12 col-md-12 mt-3 mb-3 text-center">
          <button type="button" class="btn btn-warning btn-lg" style="color: #fff;">Update</button>
        </div>
      </div>

    </div>            
</div>
@endsection