<li>
    <a href="{{URL::to('/order/'.$product->code)}}" class="col select-currency">
    <div>
        <img src="{{asset('images/'.$product->logo)}}" class="img-hover">
        <div class="top-em1">Buy with {{$product->code}}</div>
    </div>
    </a>
</li>