@extends('layouts.default')
@section('content')

<div class="row">
    <div class="col-md-12 col-sm-12 col-12" style="margin-top: 1em; margin-left: 1em; color: #000; font-weight: bold; font-size: 1.5em; padding-left: 5px;">Your my wallet here</div>
</div>  

<div class="row">
    <div class="div-white col-md-11 col-12" style="margin-bottom: 2em;">
      <br>
      <div class="col-md-12">
        <h5>Hello, {{Auth::user()->name}}</h5>
        <br>
        <h5>Current balance: 0.00000000 FIC</h5>
      </div>
      <br><br>
      <div class="col-md-12">
        Input your ETH wallet address for recive FIC
      </div>
      <form class="form-inline">
        <div class="form-group mx-sm-3 mb-4">
          <input type="text" class="form-control" id="address" placeholder="" style="width: 22em;">
        </div>
        <button type="submit" class="btn btn-success mx-sm-2 mb-4">Save</button>
      </form>
      <div>
        <h5>Transection History</h5>
      </div>
      <table class="table table-bordered table-responsive table-hover">
        <thead class="text-center bg-secondary text-white">
          <tr>
            <th>No.</th>
            <th>Date</th>
            <th>Wallet Addess</th>
            <th>Type</th>
            <th>Send</th>
            <th>FIC Recive</th>
            <th>FIC Bonuns</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody class="bg-light text-dark">
            @php($i = 1)
            @foreach($datas as $key => $data)
                @include('frontend.partials._user_transaction_list', ['data'=>$data,'order'=>$i])
                @php($i++)
            @endforeach
        </tbody>

      </table>
    </div>
</div>


@endsection