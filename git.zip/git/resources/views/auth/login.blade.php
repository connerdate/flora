@extends('layouts.plain')
@section('content')
<div class="card-header">Login</div>
<div class="card-body">
  <form action="{{$location}}" method="post">
    {{ csrf_field() }}
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input class="form-control" id="exampleInputEmail1" name="email" type="email" aria-describedby="emailHelp" placeholder="Enter email">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input class="form-control" id="exampleInputPassword1" name="password" type="password" placeholder="Password">
    </div>
    <div class="form-group">
      <div class="form-check">
        <label class="form-check-label">
          <input class="form-check-input" type="checkbox"> Remember Password</label>
      </div>
    </div>
    <input type="submit" class="btn btn-primary btn-block" value="Login" >
  </form>
  <div class="text-center">
    @if($guard == 'user')      
    <a class="d-block small mt-3" href="{{URL::to('/member/register')}}">Register an Account</a>
    @endif
    <a class="d-block small" href="{{URL::to('password/reset')}}">Forgot Password?</a>
  </div>
</div>
@endsection