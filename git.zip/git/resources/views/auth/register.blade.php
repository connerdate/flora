@extends('layouts.plain')

@section('content')
<div class="card-header">Register an Account</div>
<div class="card-body">
    <form action="{{URL::to('/member/register')}}" method="post">
        {{ csrf_field() }}
        <div class="form-group">
        <div class="form-row">
            <div class="col-md-6">
                <label for="exampleInputName">First name</label>
                <input class="form-control" name="name" id="exampleInputName" type="text" aria-describedby="nameHelp" placeholder="Enter first name">
                @if ($errors->has('name'))
                    <span class="help-block">
                        <strong>{{ $errors->first('name') }}</strong>
                    </span>
                @endif
            </div>
            <div class="col-md-6">
                <label for="exampleInputLastName">Last name</label>
                <input class="form-control" name="lastname" id="exampleInputLastName" type="text" aria-describedby="nameHelp" placeholder="Enter last name">
                @if ($errors->has('lastname'))
                    <span class="help-block">
                        <strong>{{ $errors->first('lastname') }}</strong>
                    </span>
                @endif
            </div>
        </div>
        </div>
        <div class="form-group">
        <label for="exampleInputEmail1">Email address</label>
        <input type="email" class="form-control" name="email" required="required" placeholder="Enter email">
            @if ($errors->has('lastname'))
                <span class="help-block">
                    <strong>{{ $errors->first('lastname') }}</strong>
                </span>
            @endif
        <span id="chk_email"></span>
        <input type="hidden" name="email_hidden" value="1">
        </div>
        <div class="form-group">
        <div class="form-row">
            <div class="col-md-12">
            <label for="exampleInputPassword1">Password</label>
            <input class="form-control" name="password" id="exampleInputPassword1" type="password" placeholder="Password">
            </div>
            <!-- <div class="col-md-6">
            <label for="exampleConfirmPassword">Confirm password</label>
            <input class="form-control" id="exampleConfirmPassword" type="password" placeholder="Confirm password">
            </div> -->
        </div>
        </div>
        <input type="submit" id="" value="Register" class="btn btn-primary btn-block">  
    </form>
    <div class="text-center">
        <a class="d-block small mt-3" href="{{URL::to('/member/login')}}">Login Page</a>
        <a class="d-block small" href="{{URL::to('password/reset')}}">Forgot Password?</a>
    </div>
</div>

{{--<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>--}}
@endsection

@section('style')
<link rel="stylesheet" href="{{asset('css/css_custom.css')}}">
@endsection

@section('script')
<script src="{{asset('js/jquery-3.2.1.min.js')}}"></script>
<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#regis_submit').attr({
            disabled: 'disabled'
        });

        $('input[name=email]').keyup(function(event) {
            var email = $('input[name=email]').val();
            //var user = $('input[name=user]').val();
            
            //$('#chk_email').html(email);
            //$('#chk_user').html(user);

            var type = "email";

            $.post('/api/checkUserEmail', {type:type, email: email}, function(data) {

                if (data.stt !== 'success') {
                    $('#chk_email').html('<span class="red-txt">Email in used</span>');
                    $('#regis_submit').attr({disabled:'disabled'});
                    $('input[name=email_hidden]').attr({value:'1'});
                }else if(data.stt === 'success'){
                    $('#chk_email').html('<span class="green-txt">Email available</span>');
                    $('#regis_submit').removeAttr("disabled");
                    $('input[name=email_hidden]').attr({value:'0'});
                }

            },"json");

            /*var email_hidden = $('input[name=email_hidden').val();

            console.log(email_hidden);

            if (email_hidden == 1) {
                $('#regis_submit').attr({disabled:'disabled'});
            }

            if (email_hidden == 0) {
                $('#regis_submit').removeAttr("disabled");
            }*/


        });


    });
</script>
@endsection

