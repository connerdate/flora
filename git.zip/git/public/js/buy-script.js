$(document).ready(function() {
	
	//$('#input_btc').maxlength({max: 10});
	$('#submit_order').attr({
		disabled: 'disabled'
	});

	$('#input_coin').maxlength();
	$('#receive_fic').maxlength();
	$('#fic_include_bonus').maxlength();
	
	//alert(btc_per_fic);
	$('#input_coin').keyup(function(event) {
		input_send_curreny();
	});

	$('#input_coin').change(function(){
		input_send_curreny();
	});



	function input_send_curreny(){
		var currency_per_fic = $('#input_coin').data('per-fic');
		var send_value = $('#input_coin').val();
		//console.log(send_value+'\n');
		var ttl_fic_recive = send_value*currency_per_fic;

		$('#receive_fic').attr({
			value: ttl_fic_recive
		});

		var bonus = $('#current_bonus').val();
		var bonus_percent = ttl_fic_recive*(bonus/100);

		var fic_include_bonus = ttl_fic_recive+bonus_percent;
		
		console.log(fic_include_bonus);

		$('#fic_include_bonus').attr({
			value: fic_include_bonus
		});
		//alert('dfk');

		if (send_value <= 0) {
			$('#submit_order').attr({
				disabled: 'disabled'
			});
		}

		if (send_value > 0) {
			$('#submit_order').removeAttr('disabled');
		}
	}


/*	$('#receive_fic').keyup(function(event) {
		var receive_fic = "receive_fic";
		var btc_per_fic = $('#btc_per_fic').val();
		var send_currency = "btc_per_fic";

		input_fic_recive(send_currency,receive_fic,btc_per_fic);
	});	


	function input_fic_recive(send_currency,receive_fic_param,currency_per_fic){

		var receive_fic = $('#'+receive_fic_param).val();
		console.log(receive_fic+"\n"+currency_per_fic);

		var ttl_currency_send = receive_fic/currency_per_fic;

		$('#input_btc').attr({
			value: ttl_currency_send
		});
		//alert('dfk');
	}*/



});
