<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'surname', 'code', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function referring()
    {
    return $this->belongsToMany('App\Models\User', 'user_referrer', 'user_id', 'referrer_id')->withPivot('status')
    ->withTimestamps();
    }

    // Same table, self referencing, but change the key order
    public function referrer()
    {
    return $this->belongsToMany('App\Models\User', 'user_referrer', 'referrer_id', 'user_id')->withPivot('status')
    ->withTimestamps();
    }


    public function getUsernameAttribute(){
        return $this->name.' '.$this->surname;
    }

    public function transaction()
    {
        return $this->hasMany('App\Models\Transaction');
    }

    public function commission()
    {
        return $this->hasMany('App\Models\Commission');
    }
}
