<?php

namespace App\Http\Controllers\frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

use App\Models\Transaction;

class WalletController extends Controller
{
    public function index(){
        $datas = Transaction::where('user_id',Auth::user()->id)->get();
        return view('frontend.my_wallet',compact('datas'));
    }
}
