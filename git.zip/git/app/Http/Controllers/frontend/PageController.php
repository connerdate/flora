<?php

namespace App\Http\Controllers\frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Models\Exchange;

class PageController extends Controller
{
    public function index(){
        $list = Exchange::get();
        return view('frontend.index',compact('list'));
    }
}
