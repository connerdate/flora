<?php

namespace App\Http\Controllers\backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

use App\Models\Transaction;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth:admin');
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datas = Transaction::orderBy('created_at','desc')->get();
        return view('backend.admin',compact('datas'));
    }

    public function viewTransactionData($id){
        $transaction = Transaction::find($id);
        return view('backend.transaction_detail',compact('transaction'));
    }

    public function acceptOrder(Request $request,$id){
        if($id == $request->id){
            $transaction = Transaction::where('id',$request->id)->where('status',0)->with('wallet')->with('user')->first();
            if($transaction){
                if($transaction->status == 0){
                    if($request->send_type == 1){
                        $send_amount = $transaction->send_value;      
                    }else if($request->send_type == 2){
                        $send_amount = $request->actually_coin;
                    }

                    $fic_amount = bcmul($send_amount,$transaction->fic_rate,8);
                    $fic_bonus = number_format(($fic_amount * $transaction->bonus_rate)/100, 8);
                    $all = $fic_amount+$fic_bonus;
                    $fic_all = number_format($fic_amount+$fic_bonus,8,'.','');
                    
                    $transaction->actual_send = $send_amount;
                    $transaction->actual_fic = $fic_amount;
                    $transaction->actual_bonus = $fic_bonus;
                    $transaction->actual_fic_recieve = $fic_all; 
                    $transaction->status = 1;
                    $transaction->save();
                    $userFIC = $transaction->user->fic;
                    $transaction->user->fic = number_format(($userFIC+$fic_all),8,'.',''); 
                    $transaction->user->save();

                    if($transaction->commission){
                        if($transaction->user->referring[0]->pivot->status == 0){
                            $transaction->commission->status = 1;
                            $transaction->commission->save();
                        
                            $userCommission = $transaction->commission->user->fic; 
                            $transaction->commission->user->fic = number_format(($userCommission+$transaction->commission->fic),8,'.','');
                            $transaction->commission->user->save();
                            
                            $transaction->user->referring[0]->pivot->status = 1;
                            $transaction->user->referring[0]->pivot->save();
                        }
                    }
                }
                return redirect('/cmscontrol');
            }else{
                return back();
            }
        }else{
            return back();
        }
    }
}
