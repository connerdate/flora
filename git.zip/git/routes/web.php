<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'frontend\PageController@index')->middleware('auth');
Route::get('/order/{type}', 'frontend\OrderController@index',function($type){})->middleware('auth');
Route::post('/order/{type}', 'frontend\OrderController@store',function($type){})->middleware('auth');

Route::get('/profile', 'frontend\ProfileController@index')->middleware('auth');

Route::get('/your-referrals', 'frontend\ReferralController@index')->middleware('auth');

Route::get('/my-wallet', 'frontend\WalletController@index')->middleware('auth');

Route::get('/setting', 'frontend\SettingController@index')->middleware('auth');


Route::prefix('api')->group(function() {
    Route::post('/checkUserEmail', 'API\AjaxController@checkUserEmail');
});

Route::prefix('cmscontrol')->group(function() {
    Route::get('/login', 'Auth\AdminLoginController@showLoginForm')->name('admin.login');
    Route::post('/login', 'Auth\AdminLoginController@login')->name('admin.login.submit');
    Route::get('/', 'backend\AdminController@index')->name('admin.dashboard')->middleware('auth:admin');
    Route::get('/transactionData/{id}', 'backend\AdminController@viewTransactionData',function($id){})->name('admin.transaction,data')->middleware('auth:admin');
    Route::post('/accept/order/{id}', 'backend\AdminController@acceptOrder')->middleware('auth:admin');
});
Route::get('/member/login', 'Auth\UserLoginController@showLoginForm')->name('login');
Route::post('/member/login', 'Auth\UserLoginController@login')->name('member.login.submit');
Route::get('/member/register',['use'=>'member.register',function(){
    return view('auth.register');
}]);
Route::post('/member/register', 'Auth\RegisterController@register');
Route::get('/member/logout', 'Auth\UserLoginController@logout');

Route::get('password/reset/', 'Auth\ForgotPasswordController@showLinkRequestForm',function($type){});
Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail');
Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm');
Route::post('password/reset', 'Auth\ResetPasswordController@reset');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
