<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-12 col-xs-12" style="margin-left: 1em; margin-top: 1em; color: #000; font-weight: bold; font-size: 1.5em; padding-left: 5px;">Your Countrol Panel Here</div>
      </div>  

      <div class="row">
        <div class="col-10 col-xs-12 div-white" style="margin-bottom: 2em;">
          <form>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="inputName">Name</label>
                <input type="text" class="form-control" id="name" placeholder="">
              </div>
              <div class="form-group col-md-6">
                <label for="inputLastName">Last Name</label>
                <input type="text" class="form-control" id="lastname" placeholder="">
              </div>
            </div>
            <div class="form-group">
              <label for="inputAddress">Address</label>
              <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
            </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="inputCity">City</label>
                <input type="text" class="form-control" id="city">
              </div>
              <div class="form-group col-md-6">
                <label for="inputCounty">Country</label>
                <input type="text" class="form-control" id="country">
                <!-- <select id="country" class="form-control">
                  <option selected>Thailand</option>
                  <option>...</option>
                </select> -->
              </div>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-primary btn-lg">Update Profile</button>
            </div>
          </form>
          <br>
        </div><!-- col-10 div-white -->
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>