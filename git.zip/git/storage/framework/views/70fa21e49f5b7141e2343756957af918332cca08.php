<?php $__env->startSection('content'); ?>
<div class="card-header">Login</div>
<div class="card-body">
  <form action="<?php echo e($location); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input class="form-control" id="exampleInputEmail1" name="email" type="email" aria-describedby="emailHelp" placeholder="Enter email">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input class="form-control" id="exampleInputPassword1" name="password" type="password" placeholder="Password">
    </div>
    <div class="form-group">
      <div class="form-check">
        <label class="form-check-label">
          <input class="form-check-input" type="checkbox"> Remember Password</label>
      </div>
    </div>
    <input type="submit" class="btn btn-primary btn-block" value="Login" >
  </form>
  <div class="text-center">
    <?php if($guard == 'user'): ?>      
    <a class="d-block small mt-3" href="<?php echo e(URL::to('/member/register')); ?>">Register an Account</a>
    <?php endif; ?>
    <a class="d-block small" href="<?php echo e(URL::to('password/reset')); ?>">Forgot Password?</a>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>