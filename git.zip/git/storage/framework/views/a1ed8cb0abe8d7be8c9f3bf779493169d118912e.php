<tr>
    <th scope="row"><?php echo e($order); ?></th>
    <td><?php echo e($data->created_at->format('d-m-Y H:i:s')); ?></td>
    <td><?php echo e($data->to_wallet); ?></td>
    <td><?php echo e($data->wallet->code); ?></td>
    <td><?php echo e($data->send_value); ?></td>
    <td><?php echo e($data->fic_receive); ?></td>
    <td><?php echo e($data->fic_bonus); ?></td>
    <td><span class="badge badge-pill badge-warning"><?php echo e($data->getTransactionStatusView()); ?></span></td>
</tr>