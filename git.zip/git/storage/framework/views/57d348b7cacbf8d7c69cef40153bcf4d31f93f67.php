<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6" style="margin-left: 1em; margin-top: 1em; color: #000; font-weight: bold; font-size: 1.5em; padding-left: 5px;">Calculate your investment amount</div>
</div>  
<form name="orderFIC" id="orderFIC" action="/order/<?php echo e($product->code); ?>" method="POST">
<div class="row mt-3">
<div class="col col-md-7 mt-2">
    <div class="col">
        <div class="card heigh2 heigh1">
          <div class="card-body">
            <p class="ml5">Buy FIC coins with BTC or FIC</p>
            <div class="row ">
              <!-- show exstra small -->
          
            <div class="d-xl-none d-sm-none d-md-none col-12">
                <div class="row">
                  <div class="col-3"></div>
                  <div class="select-buy-currency text-center col-6">
                    <img src="<?php echo e(asset('images/'.$product->logo)); ?>">
                    <div class="top-em1"><?php echo e($product->code); ?></div>
                  </div>
                </div>
              </div>
              <div class="d-xl-none d-sm-none d-md-none col-12">
                <div class="arrow-convert text-center mt-2 mb-2">
                  <img src="<?php echo e(asset('images/arrow-convert-down.png')); ?>" class="ex-img">
                </div>
              </div>
              <div class="d-xl-none d-sm-none d-md-none col-12">
                <div class="row">
                  <div class="col-3"></div>
                  <div class="select-buy-currency text-center col-6">
                    <img src="<?php echo e(asset('images/fic-currency.png')); ?>">
                    <div class="top-em1">FIC</div>
                  </div>
                </div>
              </div>
            </div>

            <!-- hidden exstra small -->
            <div class="row">
              <div class="col-md-1"></div>
              <div class="d-xl-block d-none d-md-block text-center col-md-4">
                <div class="col-md-12 select-buy-currency">
                  <img src="<?php echo e(asset('images/'.$product->logo)); ?>" class="img-fluid mt-4">
                  <div class="top-em1">BTC</div>
                </div>
              </div>
              <div class="d-xl-block d-none d-md-block col-md-2">
                <div class="text-center mg-top">
                  <img src="<?php echo e(asset('images/arrow-convert.png')); ?>" class="img-fluid">
                </div>
              </div>
              <div class="d-xl-block d-none d-md-block text-center col-md-4">
                <div class="col-md-12 select-buy-currency">
                  <img src="<?php echo e(asset('images/fic-currency.png')); ?>" class="img-fluid">
                  <div class="top-em1">FIC</div>
                </div>
              </div>
              <div class="col-md-1"></div>
            </div>
            <div class="row justify-content-center">
              <div class="col-12 col-md-1"></div>
              <div class="col-12 col-md-4 mt-4">
                <h6>You send:</h6>
                   <div class="input-group">
                    <input type="number" name="input_coin" class="form-control" id="input_coin" data-per-fic="<?php echo e($product->rate); ?>" value="0.00000000" style="font-size: 13px;">
                    <div class="input-group-prepend">
                        <div class="input-group-text" style="padding-left: 1px; padding-right: 1px; border-top-right-radius: 5px; border-bottom-right-radius: 5px;"><?php echo e($product->code); ?></div>
                    </div>
                  </div>
                <br>
                  <h6>You receive:</h6>
                  <div class="input-group">
                    <input type="text" class="form-control" id="receive_fic" name="receive_coin" value="0.00000000" style="font-size: 13px;">
                    <div class="input-group-prepend">
                        <div class="input-group-text" style="padding-left: 1px; padding-right: 1px; border-top-right-radius: 5px; border-bottom-right-radius: 5px;">FIC</div>
                    </div>
                  </div>
              </div>
              <div class="col-12 col-md-2"></div>
              <div class="col-12 col-md-4 mt-4 mb-3">

                  <h6>Your bonuses:</h6>
                  <div class="input-group">
                    <input type="text" class="form-control" id="" placeholder="" value="<?php echo e($product->bonus); ?>%" style="font-size: 13px; color: #f00;">
                    <input type="hidden" id="current_bonus" value="<?php echo e($product->bonus); ?>" name="">
                  </div>

                <br>
                <h6>Including bonuses:</h6>
                  <div class="input-group">
                    <input type="hidden" id="temp" name="">
                    <input type="text" class="form-control" id="fic_include_bonus" name="receive_coin_include_bonus" value="0.00000000" style="font-size: 13px;">
                    <div class="input-group-prepend">
                        <div class="input-group-text" style="padding-left: 1px; padding-right: 1px; border-top-right-radius: 5px; border-bottom-right-radius: 5px;">FIC</div>
                    </div>
                  </div>
              </div>
              <div class="col-12 col-md-1"></div>
            </div>                
          </div>
        </div>
      </div>
    </div><!-- col-md-7 -->

    <div class="col-12 col-md-5 mt-2">
      <div class="col col-md-12">
        <div class="card heigh1">
          <div class="card-body">
            <div class="" style="color: #000;">
              <h5>5 Steps Guide</h5>
            </div>
            <div class="text-16">1. Calculate how much coins you want to buy</div>
            <div class="text-16 top-em1">2. Copy/Scan the displayed address</div>
            <div class="text-16 top-em1">3. Send your cryptocurrency from any wallet you like (also exchange wallet is ok)</div>
            <div class="text-16 top-em1">4. After the payment click SUBMIT ORDER and we keep you posted with status e-mails, so check your mails</div>
            <div class="text-16 top-em1">5. Coins will be send to your FloraFIC wallet. <span style="color: #f00;">Coins can take up to 3 weeks after the ICO to appear in your wallet, but usually appear within 48 hours.</span></div>
            <br><br><br><br>
          </div>
        </div>
      </div>
    </div><!-- col-md-5 -->
</div> <!-- ROW 1 -->

<div class="row mt-3">
    <div class="col-12 col-md-7">
        <div class="col-12 col-md-12"><h5>Current exchange rate: <?php echo e($product->code); ?>/FIC =  1/<?php echo e($product->rate); ?></h5></div>
        <div class="col-12 col-md-12">Copy the address below and make the payment of  <span><?php echo e($product->code); ?></span></div>
        <textarea class="form-control col-12 col-md-12" id="Textarea1" rows="1"><?php echo e($product->wallet); ?></textarea>
    </div>      
    <div class="col-12 col-md-3">
        <div class="col-12 col-md-12 mt-3">
          <img src="<?php echo e(asset('images/'.$product->wallet_qr)); ?>">
        </div>
    </div>
</div><!-- ROW 2 -->


<div class="row">
  <div class="col-12 col-md-7 mt-3">
      <h6>Attach your wallet address ID </h6>
      <textarea class="form-control" id="Textarea1" rows="1"></textarea>
    </div>
  </div>
</div>

<div class="row mb-3">
  <div class="col-12 col-md-7">
      <div class="col-12 col-md-12">After you have send the payment to the address above please click on submit order</div>
  </div>

  <div class="col-12 col-md-7 text-center">
    <div class="col-12 col-md-12 text-center">
        <br>
        <input type="hidden" name="product_type" value="<?php echo e($product->code); ?>">
        <button type="button" class="btn btn-warning btn-lg col-12 col-md-12" id="submit_order" style="color: #fff;">
          <i class="fa fa-shopping-cart" aria-hidden="true"></i> &nbsp;Submit Order
        </button>
    </div>
  </div>

  </div>  
</div>

<!-- ROW 3 -->

<?php echo e(csrf_field()); ?>

</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/buy-script.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.plugin.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.maxlength.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#submit_order').click(function(){
            $('#orderFIC').submit();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.buywith', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>